<?php
echo <<<HTML
<h1>La Conspiration de John Hammond</h1>
<p>
    Look, I don't actually speak French. But we will still uncover the truth about John Hammond! Viva la resistance!
</p>
HTML;
?>
